FXZIN67 DEMO ANDROID — VERSION 2.0

Este é um projeto Android Studio de demonstração visual. Os botões são apenas
controles locais de interface; não interagem com Free Fire, não leem memória
do jogo e não implementam trapaças.

COMO GERAR O APK:
1. Instale Android Studio em um computador.
2. Abra a pasta FXZIN67_Demo_Android (a pasta extraída deste ZIP).
3. Aguarde o Gradle sincronizar e instalar os componentes solicitados.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

Requer Android Studio com JDK/Gradle compatíveis e Android SDK 35.

COMPILAR NA NUVEM PELO CELULAR (SEM ANDROID STUDIO):
1. Crie uma conta no GitHub e um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório (incluindo .github/workflows/build-apk.yml).
3. Abra a aba Actions e execute "Build FXZIN67 Demo APK" (ou aguarde o build após o push).
4. Quando terminar, abra a execução concluída e baixe o artifact "FXZIN67-Demo-APK".
5. Extraia o artifact para obter app-debug.apk e instale no Android.

A compilação na nuvem é executada pelo GitHub Actions; este ambiente atual não possui
Android SDK/Gradle e não tem acesso à internet para baixar as ferramentas, portanto
aqui não foi possível produzir nem testar um APK instalável.
